?package(cw1-6005-ks3g11):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="cw1-6005-ks3g11" command="/usr/bin/cw1-6005-ks3g11"
