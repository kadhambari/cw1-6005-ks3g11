#
# Regular cron jobs for the cw1-6005-ks3g11 package
#
0 4	* * *	root	[ -x /usr/bin/cw1-6005-ks3g11_maintenance ] && /usr/bin/cw1-6005-ks3g11_maintenance
