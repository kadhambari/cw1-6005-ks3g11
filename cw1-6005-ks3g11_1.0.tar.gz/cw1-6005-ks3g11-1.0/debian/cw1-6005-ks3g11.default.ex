# Defaults for cw1-6005-ks3g11 initscript
# sourced by /etc/init.d/cw1-6005-ks3g11
# installed at /etc/default/cw1-6005-ks3g11 by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
